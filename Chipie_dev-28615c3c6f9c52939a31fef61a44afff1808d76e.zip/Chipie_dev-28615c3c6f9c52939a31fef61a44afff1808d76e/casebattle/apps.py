from django.apps import AppConfig


class CasebattleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'casebattle'
